# /etc/grub/grub.cfg
set timeout=5
set default=0

menuentry "QuantumEnergyOS V.02 (x86_64)" {
    linux /boot/x86_64/vmlinuz-linux archisobasedir=arch archisolabel=QEOS_V02 quiet splash vt.global_cursor_default=0
    initrd /boot/x86_64/initramfs-linux.img
}

menuentry "QuantumEnergyOS V.02 (Modo Seguro)" {
    linux /boot/x86_64/vmlinuz-linux archisobasedir=arch archisolabel=QEOS_V02 nomodeset quiet
    initrd /boot/x86_64/initramfs-linux.img
}

menuentry "Reiniciar" {
    reboot
}

menuentry "Apagar" {
    halt
}
bootmodes=('bios.syslinux.mbr' 'bios.syslinux.eltorito'
           'uefi-ia32.grub.esp' 'uefi-x64.grub.esp'
           'uefi-x64.grub.eltorito')
