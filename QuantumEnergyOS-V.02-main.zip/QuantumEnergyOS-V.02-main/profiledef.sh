#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════
#  archiso/profiledef.sh — Perfil de construcción ISO QuantumEnergyOS
#  Basado en Arch Linux archiso + Wayland/Sway
# ═══════════════════════════════════════════════════════════════════════
iso_name="QuantumEnergyOS"
iso_label="QEOS_V02_$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m)"
iso_publisher="Giovanny Corpus Bernal <github.com/GioCorpus>"
iso_application="QuantumEnergyOS V.02 — Desde Mexicali para el mundo"
iso_version="0.2.0"
install_dir="arch"
buildmodes=('iso')
bootmodes=('bios.syslinux.mbr' 'bios.syslinux.eltorito'
           'uefi-ia32.grub.esp' 'uefi-x64.grub.esp'
           'uefi-x64.grub.eltorito')
arch="x86_64"
pacman_conf="${profile}/pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
bootstrap_tarball_compression=('zstd' '-c' '-T0' '--auto-threads=logical' '--long' '-19')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/root"]="0:0:750"
  ["/root/customize_airootfs.sh"]="0:0:755"
  ["/usr/local/bin/qeos"]="0:0:755"
  ["/usr/local/bin/qsh"]="0:0:755"
)

echo "Copiando boot script..."
cp boot/quantum-boot.sh ${airootfs_dir}/usr/local/bin/quantum-boot
chmod +x ${airootfs_dir}/usr/local/bin/quantum-boot

# Ejecutar al inicio
echo "/usr/local/bin/quantum-boot" >> ${airootfs_dir}/etc/rc.local
